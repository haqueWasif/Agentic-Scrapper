# Google Colab version

All Colab-specific files live in this folder:

- `Agentic_Scraper_Colab.ipynb`: notebook entry point.
- `pipeline_runner.py`: notebook configuration, progress and execution adapter.
- `storage.py`: optional Google Drive snapshots and restore.
- `download_benchmark.py`: optional local-overhead benchmark.
- `tests/`: notebook and adapter verification.
- `Agentic_Scraper_Colab_source.zip`: matching source bundle for uploading to Colab.
- `COLAB_IMPLEMENTATION.md`: setup instructions and implementation report.

The local Streamlit entry point remains `../app.py`. Both frontends reuse the
shared implementation and helpers in `../app/`, including download progress
throttling and PDF library/retrieval logic.

Upload the notebook to Google Colab and the source ZIP through its Files sidebar.
Set `SOURCE_ARCHIVE = '/content/Agentic_Scraper_Colab_source.zip'` in the repository
cell, use a fresh repository directory, then run the notebook sections in order.
The ZIP preserves the repository layout, including this `colab/` folder and the
shared Python modules it imports.

From the repository root, run the Colab checks with:

```shell
python -X utf8 -m unittest discover -s colab/tests -q
```

Existing local-app tests remain under `../tests/`.

Worker counts default to five downloads and two Stage 2 validations. The notebook
now accepts explicit positive-integer overrides, including 50/10. It does not
automatically increase concurrency or change source pacing/retry limits. There
is no measured maximum for your runtime; larger pools can increase memory use,
API demand and remote failures rather than throughput.
